/********************************************************************************
** Form generated from reading UI file 'interactivemanager.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INTERACTIVEMANAGER_H
#define UI_INTERACTIVEMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_InteractiveManager
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *InteractiveManager)
    {
        if (InteractiveManager->objectName().isEmpty())
            InteractiveManager->setObjectName(QStringLiteral("InteractiveManager"));
        InteractiveManager->resize(800, 600);
        menubar = new QMenuBar(InteractiveManager);
        menubar->setObjectName(QStringLiteral("menubar"));
        InteractiveManager->setMenuBar(menubar);
        centralwidget = new QWidget(InteractiveManager);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        InteractiveManager->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(InteractiveManager);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        InteractiveManager->setStatusBar(statusbar);

        retranslateUi(InteractiveManager);

        QMetaObject::connectSlotsByName(InteractiveManager);
    } // setupUi

    void retranslateUi(QMainWindow *InteractiveManager)
    {
        InteractiveManager->setWindowTitle(QApplication::translate("InteractiveManager", "MainWindow", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class InteractiveManager: public Ui_InteractiveManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INTERACTIVEMANAGER_H
