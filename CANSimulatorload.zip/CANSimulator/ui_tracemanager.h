/********************************************************************************
** Form generated from reading UI file 'tracemanager.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRACEMANAGER_H
#define UI_TRACEMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TraceManager
{
public:
    QWidget *centralwidget;
    QTreeView *treeView;

    void setupUi(QMainWindow *TraceManager)
    {
        if (TraceManager->objectName().isEmpty())
            TraceManager->setObjectName(QStringLiteral("TraceManager"));
        TraceManager->resize(738, 482);
        centralwidget = new QWidget(TraceManager);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        treeView = new QTreeView(centralwidget);
        treeView->setObjectName(QStringLiteral("treeView"));
        treeView->setGeometry(QRect(0, 0, 741, 491));
        TraceManager->setCentralWidget(centralwidget);

        retranslateUi(TraceManager);

        QMetaObject::connectSlotsByName(TraceManager);
    } // setupUi

    void retranslateUi(QMainWindow *TraceManager)
    {
        TraceManager->setWindowTitle(QApplication::translate("TraceManager", "MainWindow", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TraceManager: public Ui_TraceManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRACEMANAGER_H
