#include "filterdialoggetid.h"
#include <QPushButton>
#include <QGridLayout>
#include <QLabel>
#include <QComboBox>
#include <QWidget>
DialogGetID::DialogGetID(QWidget *parent): QDialog(parent)
{
    LabelEnter = new QLabel(tr("Enter the start and end values of the range or a single value for a message"));
    LabelStartID = new QLabel(tr("Start ID"));
    LabelEndID = new QLabel(tr("End ID"));
    LabelSpinbox = new QLabel(tr("Bus System"));
    LineEditStartID = new QLineEdit();
    LineEditEndID= new QLineEdit();
    ComboBoxBussystem = new QComboBox();
    ComboBoxBussystem->addItem("CAN");
    buttonOk = new QPushButton(tr("OK"));
    buttonCancel = new QPushButton(tr("Cancel"));

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(LabelEnter,0,0,1,2);
    mainLayout->addWidget(LabelStartID,1,0,1,1);
    mainLayout->addWidget(LabelEndID,1,1,1,1);
    mainLayout->addWidget(LabelSpinbox,1,2,1,1);
    mainLayout->addWidget(LineEditStartID,2,0,1,1);
    mainLayout->addWidget(LineEditEndID,2,1,1,1);
    mainLayout->addWidget(ComboBoxBussystem,2,2,1,1);
    mainLayout->addWidget(buttonOk,3,0,1,1);
    mainLayout->addWidget(buttonCancel,3,1,1,1);

    setLayout(mainLayout);
    setWindowTitle(tr("Message/Range selection"));
    setWindowIcon(QPixmap(":/icons/logo.png"));
    connect(buttonOk,SIGNAL(clicked()),this,SLOT(idRange()));
    connect(buttonCancel,SIGNAL(clicked()),this,SLOT(close()));
}

DialogGetID::~DialogGetID(){
    delete this;
}

void DialogGetID::idRange()
{
emit getId(LineEditStartID->text().toInt(),LineEditEndID->text().toInt());
    this->close();
}
