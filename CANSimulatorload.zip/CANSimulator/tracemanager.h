#ifndef TRACEMANAGER_H
#define TRACEMANAGER_H
#include <QCloseEvent>
#include <QMainWindow>
#include <QDialog>
namespace Ui {
class TraceManager;
}

class TraceManager : public QMainWindow
{
    Q_OBJECT

public:
    explicit TraceManager(QWidget *parent = 0);
    ~TraceManager();
    void setupItems();
protected:
    void closeEvent(QCloseEvent *event);
private:
    Ui::TraceManager *ui;
};

#endif // TRACEMANAGER_H
