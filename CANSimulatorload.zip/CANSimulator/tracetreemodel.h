#ifndef TRACETREEMODEL_H
#define TRACETREEMODEL_H
#include <QAbstractItemModel>
#include <QModelIndex>
#include <QVariant>
class TraceTreeItem;
typedef enum{
    E_DbItemType_Message = 0,
    E_DbItemType_SignalInMessage,
}E_DbItemType;

class TraceTreeModel : public QAbstractItemModel
{
    Q_OBJECT
public:

    TraceTreeModel(const QStringList &strings, QObject *parent = 0);
    ~TraceTreeModel();
    void setType(E_DbItemType itemType){m_ItemType = itemType;}
    E_DbItemType getType(){return m_ItemType;}
    QVariant data(const QModelIndex &index, int role) const;
    Qt::ItemFlags flags(const QModelIndex &index) const;
    QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const;
    QModelIndex index(int row, int column,
                      const QModelIndex &parent = QModelIndex()) const;
    QModelIndex parent(const QModelIndex &index) const;
    int rowCount(const QModelIndex &parent = QModelIndex()) const;
    int columnCount(const QModelIndex &parent = QModelIndex()) const;

    bool insertRows(int position, int rows, const QModelIndex &parent = QModelIndex());
    bool removeRows(int position, int rows, const QModelIndex &parent = QModelIndex());
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole);
    bool decodeData(int row, int column, const QModelIndex &parent, QDataStream &stream);
    QVariant a = "New_Signal_1";
    QVariant b = "New_Signal_2";
    QVariant c = "New_Signal_3";
    QVariant d = "New_Signal_4";
    QVariant e = "New_Signal_5";
private:
    void setupModelData(const QStringList &lines, TraceTreeItem *parent);
    E_DbItemType m_ItemType;
    TraceTreeItem *rootItem;

};

#endif // TRACETREEMODEL_H

